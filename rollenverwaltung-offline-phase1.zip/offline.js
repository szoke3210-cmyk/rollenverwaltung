(function () {
  const STATUS_ID = "connectionStatus";

  function ensureStatusElement() {
    let element = document.getElementById(STATUS_ID);
    if (element) return element;

    element = document.createElement("div");
    element.id = STATUS_ID;
    element.className = "connection-status";
    element.setAttribute("role", "status");
    element.setAttribute("aria-live", "polite");
    document.body.appendChild(element);
    return element;
  }

  function updateConnectionStatus() {
    const element = ensureStatusElement();
    const online = navigator.onLine;

    element.textContent = online ? "Online" : "Offline";
    element.classList.toggle("is-online", online);
    element.classList.toggle("is-offline", !online);
    document.documentElement.classList.toggle("app-offline", !online);
  }

  window.addEventListener("online", updateConnectionStatus);
  window.addEventListener("offline", updateConnectionStatus);

  document.addEventListener("DOMContentLoaded", () => {
    updateConnectionStatus();

    if (!("serviceWorker" in navigator)) {
      console.warn("Service Worker wird von diesem Browser nicht unterstützt.");
      return;
    }

    navigator.serviceWorker.register("./service-worker.js")
      .then((registration) => {
        console.log("Service Worker registriert:", registration.scope);
      })
      .catch((error) => {
        console.error("Service Worker Registrierung fehlgeschlagen:", error);
      });
  });
})();
