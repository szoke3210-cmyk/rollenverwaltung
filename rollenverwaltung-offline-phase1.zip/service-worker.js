const CACHE_VERSION = "saveline-shell-v1";
const RUNTIME_CACHE = "saveline-runtime-v1";

const CORE_ASSETS = [
  "./",
  "./index.html",
  "./manifest.json",
  "./style.css?v=8",
  "./config.js",
  "./state.js",
  "./utils.js",
  "./api.js",
  "./auth.js",
  "./aktivitaet.js",
  "./backup.js",
  "./qr.js",
  "./typen.js",
  "./statistik.js",
  "./kunden.js",
  "./scanner.js",
  "./rollen.js?v=20260720-1",
  "./app.js?v=20260720-2",
  "./offline.js?v=1",
  "./SL-LO-CO.jpg?v=2",
  "./saveway-background.png",
  "./extra-urlaub.jpg",
  "./icon-192.png",
  "./icon-512.png"
];

const EXTERNAL_ASSETS = [
  "https://unpkg.com/html5-qrcode",
  "https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"
];

self.addEventListener("install", (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_VERSION);
    await cache.addAll(CORE_ASSETS);

    await Promise.allSettled(
      EXTERNAL_ASSETS.map(async (url) => {
        const response = await fetch(url, { mode: "cors" });
        if (response.ok) await cache.put(url, response);
      })
    );

    await self.skipWaiting();
  })());
});

self.addEventListener("activate", (event) => {
  event.waitUntil((async () => {
    const keep = new Set([CACHE_VERSION, RUNTIME_CACHE]);
    const names = await caches.keys();
    await Promise.all(names.filter((name) => !keep.has(name)).map((name) => caches.delete(name)));
    await self.clients.claim();
  })());
});

self.addEventListener("fetch", (event) => {
  const request = event.request;

  if (request.method !== "GET") return;

  const url = new URL(request.url);

  // Supabase REST/Auth requests must always use the network.
  if (url.hostname.endsWith("supabase.co")) return;

  if (request.mode === "navigate") {
    event.respondWith(networkFirstNavigation(request));
    return;
  }

  event.respondWith(staleWhileRevalidate(request));
});

async function networkFirstNavigation(request) {
  try {
    const response = await fetch(request);
    const cache = await caches.open(RUNTIME_CACHE);
    cache.put(request, response.clone());
    return response;
  } catch (error) {
    return (
      await caches.match(request) ||
      await caches.match("./index.html") ||
      new Response("Offline", { status: 503, headers: { "Content-Type": "text/plain; charset=utf-8" } })
    );
  }
}

async function staleWhileRevalidate(request) {
  const cached = await caches.match(request);

  const networkPromise = fetch(request)
    .then(async (response) => {
      if (response && (response.ok || response.type === "opaque")) {
        const cache = await caches.open(RUNTIME_CACHE);
        await cache.put(request, response.clone());
      }
      return response;
    })
    .catch(() => null);

  if (cached) {
    eventWait(networkPromise);
    return cached;
  }

  const networkResponse = await networkPromise;
  if (networkResponse) return networkResponse;

  return new Response("", { status: 504, statusText: "Offline" });
}

function eventWait(promise) {
  // The promise is intentionally allowed to finish in the background.
  promise.catch(() => {});
}
